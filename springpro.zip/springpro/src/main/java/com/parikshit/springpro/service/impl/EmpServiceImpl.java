package com.parikshit.springpro.service.impl;

public class EmpServiceImpl {

}
