package com.parikshit.springpro.controller;

public class EmpController {

}
