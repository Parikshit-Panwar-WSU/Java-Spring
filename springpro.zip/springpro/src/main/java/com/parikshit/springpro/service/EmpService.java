package com.parikshit.springpro.service;

public interface EmpService {

}
