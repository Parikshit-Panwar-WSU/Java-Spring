package com.parikshit.springpro.dto;

public class EmpDto {

}
