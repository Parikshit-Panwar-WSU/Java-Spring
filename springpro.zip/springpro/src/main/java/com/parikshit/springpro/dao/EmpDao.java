package com.parikshit.springpro.dao;

public interface EmpDao {

}
