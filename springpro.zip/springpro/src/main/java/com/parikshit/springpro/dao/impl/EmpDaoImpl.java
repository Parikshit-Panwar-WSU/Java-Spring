package com.parikshit.springpro.dao.impl;

public class EmpDaoImpl {

}
